(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`food-expiry-install-dismissed`,t=`https://1259665212-djiyi59a60.ap-shanghai.tencentscf.com`,n=1080,r=.62,i=4,a=null,o=document.querySelector(`#app`);if(!o)throw Error(`App root not found`);var s={photos:[],isRecognizing:!1,progressText:``,extractedResult:null,finalResult:null,editableProductionDate:``,editableShelfLife:``,editingProductionDate:!1,editingShelfLife:!1,adjustError:null,deferredInstallPrompt:null,isInstalled:ne(),installGuideDismissed:localStorage.getItem(e)===`1`,cameraOpen:!1,cameraStarting:!1,cameraError:null,cameraCapturedCount:0};Y(),c();function c(){o.innerHTML=`
    <div class="page">
      ${J()}
      <header class="hero-card">
        <p class="eyebrow">可放到手机桌面，像平时点 App 一样打开</p>
        <h1>食品保质期检测</h1>
        <p class="intro">
          把食品包装上能拍到的地方都拍下来。系统会帮你找出生产日期、保质期和到期日期，并告诉你是不是已经过期。
        </p>
        <p class="tips">
          温馨提示：照片上传后，需要等几秒钟系统帮你识别。网络慢时请耐心等待。放到手机桌面后，下次打开会更方便。
        </p>
      </header>

      <section class="card">
        <div class="section-head">
          <h2>拍照检查</h2>
          <span class="pill">已添加 ${s.photos.length} 张</span>
        </div>
        <div class="actions">
          <button id="takePhotoButton" class="primary-btn" ${s.isRecognizing?`disabled`:``}>拍一张</button>
          <button id="openCameraButton" class="ghost-btn" ${s.isRecognizing?`disabled`:``}>连续拍照</button>
          <button id="pickPhotoButton" class="ghost-btn" ${s.isRecognizing?`disabled`:``}>从相册添加</button>
          <button id="analyzeButton" class="secondary-btn" ${s.photos.length===0||s.isRecognizing?`disabled`:``}>开始检查</button>
          <button id="clearButton" class="ghost-btn" ${s.photos.length===0||s.isRecognizing?`disabled`:``}>清空重拍</button>
        </div>
        <div class="speed-tips">
          <strong>拍照建议：</strong>平时直接点“拍一张”就行；如果想一次打开相机连续拍多面，再点“连续拍照”。建议拍 2 到 4 张，重点拍清楚“保质期说明”和“喷码日期”。
        </div>
        ${s.photos.length>i?`<div class="status-box warning">现在图片有点多，建议控制在 4 张以内，这样会更快。</div>`:``}
        <input id="takePhotoInput" class="hidden-input" type="file" accept="image/*" capture="environment" />
        <input id="albumInput" class="hidden-input" type="file" accept="image/*" multiple />
        ${s.isRecognizing?`<div class="status-box loading">
                <div>${$(s.progressText||`正在检查，请稍候...`)}</div>
                <small>一般需要 8 到 15 秒，请不要关闭页面。</small>
              </div>`:``}
        ${s.photos.length===0?`<div class="empty-box">还没有照片，请先拍包装正面、背面、侧面，以及日期附近的位置。</div>`:`<div class="photo-grid">
                ${s.photos.map(e=>`
                      <article class="photo-card">
                        <img src="${e.previewUrl}" alt="${$(e.label)}" />
                        <div class="photo-meta">
                          <span>${$(e.label)}</span>
                          <button class="link-btn" data-remove-photo="${e.id}" ${s.isRecognizing?`disabled`:``}>删除</button>
                        </div>
                      </article>
                    `).join(``)}
              </div>`}
      </section>

      <section class="card result-card">
        <div class="section-head">
          <h2>判断结果</h2>
          <span class="pill">当前日期 ${N(M())}</span>
        </div>
        ${B()}
      </section>
      ${V()}
    </div>
  `,l(),h()}function l(){let e=document.querySelector(`#takePhotoInput`),t=document.querySelector(`#albumInput`),n=document.querySelector(`#takePhotoButton`),r=document.querySelector(`#openCameraButton`),i=document.querySelector(`#pickPhotoButton`),a=document.querySelector(`#analyzeButton`),o=document.querySelector(`#clearButton`),l=document.querySelector(`#productionDateYear`),h=document.querySelector(`#productionDateMonth`),g=document.querySelector(`#productionDateDay`),v=document.querySelector(`#shelfLifeValue`),y=document.querySelector(`#shelfLifeUnit`),b=document.querySelector(`#installAppButton`),x=document.querySelector(`#dismissInstallGuideButton`),S=document.querySelector(`#editProductionDateButton`),C=document.querySelector(`#saveProductionDateButton`),w=document.querySelector(`#cancelProductionDateButton`),T=document.querySelector(`#editShelfLifeButton`),E=document.querySelector(`#saveShelfLifeButton`),D=document.querySelector(`#cancelShelfLifeButton`),O=document.querySelector(`#captureCameraButton`),k=document.querySelector(`#finishCameraButton`),A=document.querySelector(`#closeCameraButton`),j=document.querySelector(`#cameraPickAlbumButton`);n?.addEventListener(`click`,()=>e?.click()),r?.addEventListener(`click`,()=>{ee(e)}),i?.addEventListener(`click`,()=>t?.click()),e?.addEventListener(`change`,t=>{u(Array.from(t.target.files??[])),e&&(e.value=``)}),t?.addEventListener(`change`,e=>{u(Array.from(e.target.files??[])),t&&(t.value=``)}),a?.addEventListener(`click`,()=>{_()}),o?.addEventListener(`click`,()=>f());let M=e=>{if(!l||!h||!g)return;let t=Number(l.value),n=Number(h.value),r=F(t,n),i=Math.min(Number(g.value),r);s.editableProductionDate=`${t}-${String(n).padStart(2,`0`)}-${String(i).padStart(2,`0`)}`,e&&c()};l?.addEventListener(`change`,()=>M(!0)),h?.addEventListener(`change`,()=>M(!0)),g?.addEventListener(`change`,()=>M(!1));let N=e=>{if(!v||!y)return;let t=y.value,n=I(t);s.editableShelfLife=`${Math.min(Number(v.value),n)}${t===`day`?`天`:t===`month`?`个月`:`年`}`,e&&c()};v?.addEventListener(`change`,()=>N(!1)),y?.addEventListener(`change`,()=>N(!0)),document.querySelectorAll(`[data-remove-photo]`).forEach(e=>{e.addEventListener(`click`,()=>{d(e.dataset.removePhoto??``)})}),b?.addEventListener(`click`,()=>{X()}),x?.addEventListener(`click`,()=>{Z()}),S?.addEventListener(`click`,()=>{s.adjustError=null,s.editingProductionDate=!0,c()}),C?.addEventListener(`click`,()=>{K(`productionDate`)}),w?.addEventListener(`click`,()=>{q(`productionDate`)}),T?.addEventListener(`click`,()=>{s.adjustError=null,s.editingShelfLife=!0,c()}),E?.addEventListener(`click`,()=>{K(`shelfLife`)}),D?.addEventListener(`click`,()=>{q(`shelfLife`)}),O?.addEventListener(`click`,()=>{m()}),k?.addEventListener(`click`,()=>{p()}),A?.addEventListener(`click`,()=>{p()}),j?.addEventListener(`click`,()=>{t?.click()})}function u(e){if(e.length===0)return;let t=e.map((e,t)=>({id:crypto.randomUUID(),file:e,label:`包装第 ${s.photos.length+t+1} 面`,previewUrl:URL.createObjectURL(e)}));s.photos=[...s.photos,...t],s.extractedResult=null,s.finalResult=null,s.editableProductionDate=``,s.editableShelfLife=``,s.editingProductionDate=!1,s.editingShelfLife=!1,s.adjustError=null,c()}function d(e){let t=s.photos.find(t=>t.id===e);t&&URL.revokeObjectURL(t.previewUrl),s.photos=s.photos.filter(t=>t.id!==e).map((e,t)=>({...e,label:`包装第 ${t+1} 面`})),s.extractedResult=null,s.finalResult=null,s.editableProductionDate=``,s.editableShelfLife=``,s.editingProductionDate=!1,s.editingShelfLife=!1,s.adjustError=null,c()}function f(){s.photos.forEach(e=>URL.revokeObjectURL(e.previewUrl)),s.photos=[],s.extractedResult=null,s.finalResult=null,s.editableProductionDate=``,s.editableShelfLife=``,s.editingProductionDate=!1,s.editingShelfLife=!1,s.adjustError=null,s.progressText=``,c()}async function ee(e){if(!s.isRecognizing){if(!g()){e?.click();return}p(!1),s.cameraOpen=!0,s.cameraStarting=!0,s.cameraError=null,s.cameraCapturedCount=0,c();try{a=await navigator.mediaDevices.getUserMedia({audio:!1,video:{facingMode:{ideal:`environment`}}}),s.cameraStarting=!1,s.cameraError=null,c()}catch{s.cameraStarting=!1,s.cameraError=`打开相机失败，请改用“从相册添加”，或检查浏览器是否允许使用相机。`,c()}}}function p(e=!0){a?.getTracks().forEach(e=>e.stop()),a=null,s.cameraOpen=!1,s.cameraStarting=!1,s.cameraError=null,s.cameraCapturedCount=0,e&&c()}async function m(){let e=document.querySelector(`#cameraPreview`);if(!e||!a){s.cameraError=`相机画面还没准备好，请稍等一下。`,c();return}if(e.videoWidth===0||e.videoHeight===0){s.cameraError=`相机画面还没准备好，请稍等一下。`,c();return}let t=document.createElement(`canvas`);t.width=e.videoWidth,t.height=e.videoHeight;let n=t.getContext(`2d`);if(!n){s.cameraError=`相机拍照失败，请改用“从相册添加”。`,c();return}n.drawImage(e,0,0,t.width,t.height);let r=await new Promise(e=>{t.toBlob(e,`image/jpeg`,.88)});if(!r){s.cameraError=`相机拍照失败，请重试一次。`,c();return}s.cameraError=null,s.cameraCapturedCount+=1,u([new File([r],`camera-${Date.now()}.jpg`,{type:`image/jpeg`,lastModified:Date.now()})])}function h(){let e=document.querySelector(`#cameraPreview`);!e||!a||(e.srcObject!==a&&(e.srcObject=a),e.play().catch(()=>void 0))}function g(){return!!(window.isSecureContext&&navigator.mediaDevices?.getUserMedia)}async function _(){if(s.photos.length!==0){s.isRecognizing=!0,s.progressText=`正在准备照片...`,s.extractedResult=null,s.finalResult=null,c();try{let e=[];for(let[t,n]of s.photos.entries())s.progressText=`正在处理第 ${t+1} / ${s.photos.length} 张照片...`,c(),e.push(await D(n.file));s.progressText=s.photos.length>i?`照片较多，处理会慢一些，请耐心等待...`:`正在帮你识别，请稍候...`,c();let t=await E(e);s.extractedResult=t,s.finalResult=t.isExpired===null?null:t,s.editableProductionDate=t.productionDate??``,s.editableShelfLife=t.shelfLifeText??``,s.editingProductionDate=!1,s.editingShelfLife=!1,s.adjustError=null}catch(e){let t=e instanceof Error?e.message:`识别时出现异常，请重新尝试。`;s.extractedResult={productionDate:null,shelfLifeText:null,expiryDate:null,currentDate:M(),isExpired:null,reason:`识别失败：${t}`,remainingDays:null,recognizedText:``},s.finalResult=null,s.editableProductionDate=``,s.editableShelfLife=``,s.editingProductionDate=!1,s.editingShelfLife=!1,s.adjustError=null}finally{s.isRecognizing=!1,s.progressText=``,c()}}}function v(e,t,n,r){let i=C(e);if(!i)return{productionDate:null,shelfLifeText:t.trim()||null,expiryDate:null,currentDate:r,isExpired:null,remainingDays:null,reason:`生产日期格式不正确，请输入例如 2026-05-09。`,recognizedText:n};let a=y(t);if(!a)return{productionDate:i,shelfLifeText:t.trim()||null,expiryDate:null,currentDate:r,isExpired:null,remainingDays:null,reason:`保质期格式不正确，请输入例如 30天、6个月、1年。`,recognizedText:n};let o=T(S(w(i),a)),s=P(r,o),c=s<0;return{productionDate:i,shelfLifeText:a.rawText,expiryDate:o,currentDate:r,isExpired:c,remainingDays:s,reason:null,recognizedText:n}}function y(e){let t=e.replace(/\s+/g,``).trim(),n=t.match(/^(\d{1,3})(个?月|天|日|年)$/);return n?x(n[1],n[2]):b(t)}function b(e){for(let t of e.matchAll(/(保质期|保存期|质保期|保期|保藏期|贮藏期|賞味期限|最佳食用期|建议尽快饮用)[:：]?[^\d]{0,8}(\d{1,3})\s*(个?月|天|日|年)/gi)){let e=x(t[2],t[3]);if(e)return e}for(let t of e.matchAll(/(\d{1,3})\s*(个?月|天|日|年)/g)){let n=Math.max(0,(t.index??0)-12),r=e.slice(n,n+24);if(/(保质期|保存期|质保期|保期|保藏期|贮藏期|常温保存|阴凉干燥处|开盖后|冷藏)/.test(r))return x(t[1],t[2])}return null}function x(e,t){let n=Number.parseInt(e,10);return Number.isNaN(n)||n<=0?null:t===`天`||t===`日`?{value:n,unit:`day`,rawText:`${n}${t}`}:t===`个月`||t===`月`?{value:n,unit:`month`,rawText:`${n}${t}`}:t===`年`?{value:n,unit:`year`,rawText:`${n}${t}`}:null}function S(e,t){let n=new Date(e.getTime());return t.unit===`day`?n.setDate(n.getDate()+t.value):t.unit===`month`?n.setMonth(n.getMonth()+t.value):n.setFullYear(n.getFullYear()+t.value),n}function C(e){let t=e.trim().replaceAll(`年`,`-`).replaceAll(`月`,`-`).replaceAll(`日`,``).replaceAll(`/`,`-`).replaceAll(`.`,`-`),n=t.match(/^(20\d{2})(\d{2})(\d{2})$/);if(n)return C(`${n[1]}-${n[2]}-${n[3]}`);let r=t.match(/^(20\d{2})-(\d{1,2})-(\d{1,2})$/);if(!r)return null;let i=Number.parseInt(r[1],10),a=Number.parseInt(r[2],10),o=Number.parseInt(r[3],10),s=new Date(i,a-1,o);return s.getFullYear()!==i||s.getMonth()!==a-1||s.getDate()!==o?null:`${i}-${String(a).padStart(2,`0`)}-${String(o).padStart(2,`0`)}`}function w(e){let[t,n,r]=e.split(`-`).map(e=>Number.parseInt(e,10));return new Date(t,n-1,r)}function T(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}async function E(e){let n=await fetch(t,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({op:`run`,images:e})}),r=await n.json().catch(()=>null);if(!n.ok)throw Error(r?.reason||`云端接口请求失败（${n.status}）`);if(!r)throw Error(`云端接口没有返回有效数据。`);return{productionDate:r.productionDate??null,shelfLifeText:r.shelfLifeText??null,expiryDate:r.expiryDate??null,currentDate:r.currentDate??M(),isExpired:r.isExpired??null,remainingDays:typeof r.remainingDays==`number`?r.remainingDays:null,reason:r.reason??null,recognizedText:r.recognizedText??``}}async function D(e){let t=await O(e);return{fileName:e.name||`photo-${Date.now()}.jpg`,contentType:`image/jpeg`,dataUrl:t}}async function O(e){let t=await A(e);if(!e.type.startsWith(`image/`))return t;try{let e=await j(t),i=Math.min(1,n/Math.max(e.naturalWidth,e.naturalHeight)),a=Math.max(1,Math.round(e.naturalWidth*i)),o=Math.max(1,Math.round(e.naturalHeight*i)),s=document.createElement(`canvas`);s.width=a,s.height=o;let c=s.getContext(`2d`);return c?(c.drawImage(e,0,0,a,o),await k(s,r)):t}catch{return t}}function k(e,t){return new Promise(n=>{e.toBlob(r=>{if(!r){n(e.toDataURL(`image/jpeg`,t));return}let i=new FileReader;i.onload=()=>{n(typeof i.result==`string`?i.result:e.toDataURL(`image/jpeg`,t))},i.onerror=()=>n(e.toDataURL(`image/jpeg`,t)),i.readAsDataURL(r)},`image/jpeg`,t)})}function A(e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>{if(typeof r.result==`string`){t(r.result);return}n(Error(`读取图片失败，请重试。`))},r.onerror=()=>n(Error(`读取图片失败，请重试。`)),r.readAsDataURL(e)})}function j(e){return new Promise((t,n)=>{let r=new Image;r.onload=()=>t(r),r.onerror=()=>n(Error(`图片解码失败，请重试。`)),r.src=e})}function M(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}function N(e){let t=w(e);return`${t.getFullYear()}年${t.getMonth()+1}月${t.getDate()}日`}function P(e,t){let n=w(e),r=w(t);return Math.floor((r.getTime()-n.getTime())/864e5)}function F(e,t){return new Date(e,t,0).getDate()}function I(e){return e===`day`?365:e===`month`?36:10}function L(e,t,n){return e.map(e=>`<option value="${e}" ${e===t?`selected`:``}>${n(e)}</option>`).join(``)}function R(e){let[t,n,r]=(C(e)??M()).split(`-`),i=Number(t),a=Number(n),o=Number(r),s=new Date().getFullYear(),c=Math.max(2e3,s-20),l=Array.from({length:s-c+1},(e,t)=>s-t),u=Array.from({length:12},(e,t)=>t+1),d=Array.from({length:F(i,a)},(e,t)=>t+1);return`
    <div class="date-picker-group production-date-picker-group">
      <label class="date-picker-field date-picker-field-year" for="productionDateYear">
        <span>年份</span>
        <select id="productionDateYear">
          ${L(l,i,e=>`${e}`)}
        </select>
      </label>
      <label class="date-picker-field" for="productionDateMonth">
        <span>月份</span>
        <select id="productionDateMonth">
          ${L(u,a,e=>`${e}`)}
        </select>
      </label>
      <label class="date-picker-field" for="productionDateDay">
        <span>日期</span>
        <select id="productionDateDay">
          ${L(d,o,e=>`${e}`)}
        </select>
      </label>
    </div>
  `}function z(e){let t=y(e)??{value:12,unit:`month`,rawText:`12个月`};return`
    <div class="date-picker-group shelf-life-picker-group">
      <label class="date-picker-field" for="shelfLifeValue">
        <span>数值</span>
        <select id="shelfLifeValue">
          ${L(Array.from({length:I(t.unit)},(e,t)=>t+1),t.value,e=>`${e}`)}
        </select>
      </label>
      <label class="date-picker-field" for="shelfLifeUnit">
        <span>单位</span>
        <select id="shelfLifeUnit">
          ${[{value:`day`,label:`天`},{value:`month`,label:`月`},{value:`year`,label:`年`}].map(e=>`<option value="${e.value}" ${e.value===t.unit?`selected`:``}>${e.label}</option>`).join(``)}
        </select>
      </label>
    </div>
  `}function B(){return s.isRecognizing?`<div class="status-box loading">${$(s.progressText||`正在识别，请稍候...`)}</div>`:s.extractedResult?s.finalResult?`
    <div class="result-grid">
      ${H(`productionDate`)}
      ${H(`shelfLife`)}
      <div><span>到期日期</span><strong>${N(s.finalResult.expiryDate??s.finalResult.currentDate)}</strong></div>
      <div><span>还剩天数</span><strong class="${s.finalResult.remainingDays!==null&&s.finalResult.remainingDays<0?`expired`:`fresh`}">${G(s.finalResult.remainingDays)}</strong></div>
      <div><span>当前日期</span><strong>${N(s.finalResult.currentDate)}</strong></div>
      <div><span>是否过期</span><strong class="${s.finalResult.isExpired?`expired`:`fresh`}">${W(s.finalResult.isExpired)}</strong></div>
    </div>
    ${s.adjustError?`<div class="status-box warning">调整失败：${$(s.adjustError)}</div>`:``}
    ${U(s.finalResult.recognizedText)}
  `:`
      <div class="status-box warning">错误：${$(s.extractedResult.reason??`无法提取信息。`)}</div>
      ${U(s.extractedResult.recognizedText)}
    `:`<div class="empty-box">拍照完成后，点“开始检查”，系统就会帮你找出生产日期和保质期。</div>`}function V(){return s.cameraOpen?`
    <div class="camera-overlay">
      <section class="camera-sheet">
        <div class="camera-sheet-head">
          <div>
            <p class="camera-sheet-title">连续拍照</p>
            <p class="camera-sheet-text">打开一次相机后，可以连续拍多张，拍够了再点“拍好了”。部分手机第一次使用时会先确认相机权限。</p>
          </div>
          <button id="closeCameraButton" class="ghost-btn camera-close-btn">关闭</button>
        </div>
        <div class="camera-sheet-status">
          <span class="pill">本次已拍 ${s.cameraCapturedCount} 张</span>
        </div>
        ${s.cameraStarting?`<div class="status-box loading">正在打开相机，请稍候...</div>`:s.cameraError?`<div class="status-box warning">${$(s.cameraError)}</div>`:`<div class="camera-preview-wrap">
                  <video id="cameraPreview" autoplay playsinline muted></video>
                </div>`}
        <div class="camera-help">
          先对准包装拍一张，再移动到其他面继续拍。建议重点拍保质期说明和喷码日期。
        </div>
        <div class="camera-actions">
          <button id="captureCameraButton" class="primary-btn" ${s.cameraStarting||s.isRecognizing?`disabled`:``}>拍一张</button>
          <button id="finishCameraButton" class="secondary-btn">拍好了</button>
          <button id="cameraPickAlbumButton" class="ghost-btn">从相册添加</button>
        </div>
      </section>
    </div>
  `:``}function H(e){let t=e===`productionDate`,n=t?s.editingProductionDate:s.editingShelfLife,r=t?`editProductionDateButton`:`editShelfLifeButton`,i=t?`saveProductionDateButton`:`saveShelfLifeButton`,a=t?`cancelProductionDateButton`:`cancelShelfLifeButton`,o=t?`生产日期`:`保质期`,c=t?s.editableProductionDate:s.editableShelfLife,l=t?c?N(c):`未识别到`:c||`未识别到`;return n?`
    <div class="adjustable-card editing">
      <span>${o}</span>
      ${t?`${R(c)}<small class="input-hint">请按顺序选择年、月、日。</small>`:`${z(c)}<small class="input-hint">请先选数字，再选单位。</small>`}
      <div class="inline-actions">
        <button id="${i}" class="field-btn primary-inline-btn">保存</button>
        <button id="${a}" class="field-btn">取消</button>
      </div>
    </div>
  `:`
      <div class="adjustable-card">
        <span>${o}</span>
        <strong>${$(l)}</strong>
        <button id="${r}" class="field-btn">调整</button>
      </div>
    `}function U(e){return e.trim()?`
    <details class="details-box">
      <summary>查看识别到的原始文字</summary>
      <pre>${$(e)}</pre>
    </details>
  `:``}function W(e){return e===!0?`已过期`:e===!1?`未过期`:`暂时无法判断`}function G(e){return e===null?`暂时无法判断`:e>0?`还剩 ${e} 天`:e===0?`今天到期`:`已超过 ${Math.abs(e)} 天`}function K(e){if(!s.extractedResult)return;let t=v(s.editableProductionDate,s.editableShelfLife,s.extractedResult.recognizedText,s.extractedResult.currentDate);if(t.isExpired===null){s.adjustError=t.reason,c();return}s.finalResult=t,s.adjustError=null,e===`productionDate`?s.editingProductionDate=!1:s.editingShelfLife=!1,c()}function q(e){s.finalResult&&(e===`productionDate`?(s.editableProductionDate=s.finalResult.productionDate??``,s.editingProductionDate=!1):(s.editableShelfLife=s.finalResult.shelfLifeText??``,s.editingShelfLife=!1),s.adjustError=null,c())}function J(){return s.isInstalled||s.installGuideDismissed?``:s.deferredInstallPrompt?`
      <section class="install-guide">
        <div>
          <p class="install-guide-title">建议放到手机桌面</p>
          <p class="install-guide-text">放到桌面后，下次只要点一下图标，就能直接打开，不用再去浏览器里找。</p>
        </div>
        <div class="install-guide-actions">
          <button id="installAppButton" class="primary-btn">放到桌面</button>
          <button id="dismissInstallGuideButton" class="ghost-btn">稍后再说</button>
        </div>
      </section>
    `:Q()?`
      <section class="install-guide">
        <div>
          <p class="install-guide-title">可放到手机桌面</p>
          <p class="install-guide-text">iPhone 请先点浏览器下面的“分享”，再点“添加到主屏幕”，以后就能直接从桌面打开。</p>
        </div>
        <div class="install-guide-actions">
          <button id="dismissInstallGuideButton" class="ghost-btn">我知道了</button>
        </div>
      </section>
    `:``}function Y(){window.addEventListener(`beforeinstallprompt`,t=>{t.preventDefault(),s.deferredInstallPrompt=t,s.installGuideDismissed=!1,localStorage.removeItem(e),c()}),window.addEventListener(`appinstalled`,()=>{s.isInstalled=!0,s.deferredInstallPrompt=null,c()})}async function X(){if(!s.deferredInstallPrompt)return;let t=s.deferredInstallPrompt;await t.prompt();let n=await t.userChoice;s.deferredInstallPrompt=null,n.outcome!==`accepted`&&(s.installGuideDismissed=!0,localStorage.setItem(e,`1`)),c()}function Z(){s.installGuideDismissed=!0,localStorage.setItem(e,`1`),c()}function Q(){return te()&&!s.isInstalled}function te(){return/iphone|ipad|ipod/i.test(window.navigator.userAgent)}function ne(){let e=window.navigator;return window.matchMedia(`(display-mode: standalone)`).matches||e.standalone===!0}function $(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#39;`)}