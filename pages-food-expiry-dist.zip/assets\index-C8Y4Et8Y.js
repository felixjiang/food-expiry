(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`food-expiry-install-dismissed`,t=`https://1259665212-djiyi59a60.ap-shanghai.tencentscf.com`,n=document.querySelector(`#app`);if(!n)throw Error(`App root not found`);var r={photos:[],isRecognizing:!1,progressText:``,extractedResult:null,finalResult:null,editableProductionDate:``,editableShelfLife:``,editingProductionDate:!1,editingShelfLife:!1,adjustError:null,deferredInstallPrompt:null,isInstalled:F(),installGuideDismissed:localStorage.getItem(e)===`1`};A(),i();function i(){n.innerHTML=`
    <div class="page">
      ${k()}
      <header class="hero-card">
        <p class="eyebrow">可部署 PWA，可添加到桌面</p>
        <h1>食品保质期检测</h1>
        <p class="intro">
          把包装所有能拍到的面都拍下来。系统会通过云端识别提取生产日期、保质期和到期日期，如有偏差可在结果中调整。
        </p>
        <p class="tips">
          温馨提示：识别时会把图片发送到云端 OCR 服务，网络较慢时请耐心等待；安装到桌面后打开会更像 App。
        </p>
      </header>

      <section class="card">
        <div class="section-head">
          <h2>拍照与上传</h2>
          <span class="pill">已添加 ${r.photos.length} 张</span>
        </div>
        <div class="actions">
          <button id="pickPhotoButton" class="primary-btn" ${r.isRecognizing?`disabled`:``}>拍照 / 添加图片</button>
          <button id="analyzeButton" class="secondary-btn" ${r.photos.length===0||r.isRecognizing?`disabled`:``}>开始识别</button>
          <button id="clearButton" class="ghost-btn" ${r.photos.length===0||r.isRecognizing?`disabled`:``}>清空重拍</button>
        </div>
        <input id="photoInput" class="hidden-input" type="file" accept="image/*" capture="environment" multiple />
        ${r.isRecognizing?`<div class="status-box loading">${I(r.progressText||`正在识别，请稍候...`)}</div>`:``}
        ${r.photos.length===0?`<div class="empty-box">还没有图片，请先拍摄包装的正面、背面、侧面和日期附近区域。</div>`:`<div class="photo-grid">
                ${r.photos.map(e=>`
                      <article class="photo-card">
                        <img src="${e.previewUrl}" alt="${I(e.label)}" />
                        <div class="photo-meta">
                          <span>${I(e.label)}</span>
                          <button class="link-btn" data-remove-photo="${e.id}" ${r.isRecognizing?`disabled`:``}>删除</button>
                        </div>
                      </article>
                    `).join(``)}
              </div>`}
      </section>

      <section class="card result-card">
        <div class="section-head">
          <h2>判断结果</h2>
          <span class="pill">当前日期 ${S(x())}</span>
        </div>
        ${C()}
      </section>
    </div>
  `,a()}function a(){let e=document.querySelector(`#photoInput`),t=document.querySelector(`#pickPhotoButton`),n=document.querySelector(`#analyzeButton`),a=document.querySelector(`#clearButton`),u=document.querySelector(`#productionDateInput`),d=document.querySelector(`#shelfLifeInput`),f=document.querySelector(`#installAppButton`),p=document.querySelector(`#dismissInstallGuideButton`),m=document.querySelector(`#editProductionDateButton`),h=document.querySelector(`#saveProductionDateButton`),g=document.querySelector(`#cancelProductionDateButton`),_=document.querySelector(`#editShelfLifeButton`),v=document.querySelector(`#saveShelfLifeButton`),y=document.querySelector(`#cancelShelfLifeButton`);t?.addEventListener(`click`,()=>e?.click()),e?.addEventListener(`change`,t=>{o(Array.from(t.target.files??[])),e&&(e.value=``)}),n?.addEventListener(`click`,()=>{l()}),a?.addEventListener(`click`,()=>c()),u?.addEventListener(`input`,e=>{r.editableProductionDate=e.target.value}),d?.addEventListener(`input`,e=>{r.editableShelfLife=e.target.value}),document.querySelectorAll(`[data-remove-photo]`).forEach(e=>{e.addEventListener(`click`,()=>{s(e.dataset.removePhoto??``)})}),f?.addEventListener(`click`,()=>{j()}),p?.addEventListener(`click`,()=>{M()}),m?.addEventListener(`click`,()=>{r.adjustError=null,r.editingProductionDate=!0,i()}),h?.addEventListener(`click`,()=>{D(`productionDate`)}),g?.addEventListener(`click`,()=>{O(`productionDate`)}),_?.addEventListener(`click`,()=>{r.adjustError=null,r.editingShelfLife=!0,i()}),v?.addEventListener(`click`,()=>{D(`shelfLife`)}),y?.addEventListener(`click`,()=>{O(`shelfLife`)})}function o(e){if(e.length===0)return;let t=e.map((e,t)=>({id:crypto.randomUUID(),file:e,label:`包装第 ${r.photos.length+t+1} 面`,previewUrl:URL.createObjectURL(e)}));r.photos=[...r.photos,...t],r.extractedResult=null,r.finalResult=null,r.editableProductionDate=``,r.editableShelfLife=``,r.editingProductionDate=!1,r.editingShelfLife=!1,r.adjustError=null,i()}function s(e){let t=r.photos.find(t=>t.id===e);t&&URL.revokeObjectURL(t.previewUrl),r.photos=r.photos.filter(t=>t.id!==e).map((e,t)=>({...e,label:`包装第 ${t+1} 面`})),r.extractedResult=null,r.finalResult=null,r.editableProductionDate=``,r.editableShelfLife=``,r.editingProductionDate=!1,r.editingShelfLife=!1,r.adjustError=null,i()}function c(){r.photos.forEach(e=>URL.revokeObjectURL(e.previewUrl)),r.photos=[],r.extractedResult=null,r.finalResult=null,r.editableProductionDate=``,r.editableShelfLife=``,r.editingProductionDate=!1,r.editingShelfLife=!1,r.adjustError=null,r.progressText=``,i()}async function l(){if(r.photos.length!==0){r.isRecognizing=!0,r.progressText=`正在准备图片上传...`,r.extractedResult=null,r.finalResult=null,i();try{r.progressText=`正在获取上传授权...`,i();let e=await y(r.photos.map(e=>({fileName:e.file.name,contentType:e.file.type||`image/jpeg`})));for(let[t,n]of r.photos.entries())r.progressText=`正在上传第 ${t+1} / ${r.photos.length} 张图片...`,i(),await b(n.file,e[t]);r.progressText=`正在调用腾讯云 OCR 服务...`,i();let t=await v(e.map(e=>e.key));r.extractedResult=t,r.finalResult=t.isExpired===null?null:t,r.editableProductionDate=t.productionDate??``,r.editableShelfLife=t.shelfLifeText??``,r.editingProductionDate=!1,r.editingShelfLife=!1,r.adjustError=null}catch(e){let t=e instanceof Error?e.message:`识别时出现异常，请重新尝试。`;r.extractedResult={productionDate:null,shelfLifeText:null,expiryDate:null,currentDate:x(),isExpired:null,reason:`识别失败：${t}`,recognizedText:``},r.finalResult=null,r.editableProductionDate=``,r.editableShelfLife=``,r.editingProductionDate=!1,r.editingShelfLife=!1,r.adjustError=null}finally{r.isRecognizing=!1,r.progressText=``,i()}}}function u(e,t,n,r){let i=h(e);if(!i)return{productionDate:null,shelfLifeText:t.trim()||null,expiryDate:null,currentDate:r,isExpired:null,reason:`生产日期格式不正确，请输入例如 2026-05-09。`,recognizedText:n};let a=d(t);if(!a)return{productionDate:i,shelfLifeText:t.trim()||null,expiryDate:null,currentDate:r,isExpired:null,reason:`保质期格式不正确，请输入例如 30天、6个月、1年。`,recognizedText:n};let o=m(g(i),a),s=g(r).getTime()>o.getTime();return{productionDate:i,shelfLifeText:a.rawText,expiryDate:_(o),currentDate:r,isExpired:s,reason:null,recognizedText:n}}function d(e){let t=e.replace(/\s+/g,``).trim(),n=t.match(/^(\d{1,3})(个?月|天|日|年)$/);return n?p(n[1],n[2]):f(t)}function f(e){for(let t of e.matchAll(/(保质期|保存期|质保期|保期|保藏期|贮藏期|賞味期限|最佳食用期|建议尽快饮用)[:：]?[^\d]{0,8}(\d{1,3})\s*(个?月|天|日|年)/gi)){let e=p(t[2],t[3]);if(e)return e}for(let t of e.matchAll(/(\d{1,3})\s*(个?月|天|日|年)/g)){let n=Math.max(0,(t.index??0)-12),r=e.slice(n,n+24);if(/(保质期|保存期|质保期|保期|保藏期|贮藏期|常温保存|阴凉干燥处|开盖后|冷藏)/.test(r))return p(t[1],t[2])}return null}function p(e,t){let n=Number.parseInt(e,10);return Number.isNaN(n)||n<=0?null:t===`天`||t===`日`?{value:n,unit:`day`,rawText:`${n}${t}`}:t===`个月`||t===`月`?{value:n,unit:`month`,rawText:`${n}${t}`}:t===`年`?{value:n,unit:`year`,rawText:`${n}${t}`}:null}function m(e,t){let n=new Date(e.getTime());return t.unit===`day`?n.setDate(n.getDate()+t.value):t.unit===`month`?n.setMonth(n.getMonth()+t.value):n.setFullYear(n.getFullYear()+t.value),n}function h(e){let t=e.trim().replaceAll(`年`,`-`).replaceAll(`月`,`-`).replaceAll(`日`,``).replaceAll(`/`,`-`).replaceAll(`.`,`-`),n=t.match(/^(20\d{2})(\d{2})(\d{2})$/);if(n)return h(`${n[1]}-${n[2]}-${n[3]}`);let r=t.match(/^(20\d{2})-(\d{1,2})-(\d{1,2})$/);if(!r)return null;let i=Number.parseInt(r[1],10),a=Number.parseInt(r[2],10),o=Number.parseInt(r[3],10),s=new Date(i,a-1,o);return s.getFullYear()!==i||s.getMonth()!==a-1||s.getDate()!==o?null:`${i}-${String(a).padStart(2,`0`)}-${String(o).padStart(2,`0`)}`}function g(e){let[t,n,r]=e.split(`-`).map(e=>Number.parseInt(e,10));return new Date(t,n-1,r)}function _(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}async function v(e){let n=Object.fromEntries(e.map((e,t)=>[`r${t+1}`,e])),r=new URLSearchParams;r.set(`op`,`run`);for(let[e,t]of Object.entries(n))r.set(e,t);let i=await fetch(t,{method:`POST`,headers:{"Content-Type":`application/x-www-form-urlencoded;charset=UTF-8`},body:r.toString()}),a=await i.json().catch(()=>null);if(!i.ok)throw Error(a?.reason||`云端接口请求失败（${i.status}）`);if(!a)throw Error(`云端接口没有返回有效数据。`);return{productionDate:a.productionDate??null,shelfLifeText:a.shelfLifeText??null,expiryDate:a.expiryDate??null,currentDate:a.currentDate??x(),isExpired:a.isExpired??null,reason:a.reason??null,recognizedText:a.recognizedText??``}}async function y(e){let n=await fetch(t,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({action:`createUploadPlan`,files:e})}),r=await n.json().catch(()=>null);if(!n.ok)throw Error(r?.reason||`获取上传授权失败（${n.status}）`);let i=r?.uploadTargets??[];if(i.length!==e.length)throw Error(`上传授权返回数量不正确，请重试。`);return i}async function b(e,t){let n=await fetch(t.uploadUrl,{method:`PUT`,headers:{"Content-Type":e.type||t.contentType||`application/octet-stream`},body:e});if(!n.ok)throw Error(`上传图片到 COS 失败（${n.status}）。请检查 COS 存储桶是否已为当前站点配置 CORS。`)}function x(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}function S(e){let t=g(e);return`${t.getFullYear()}年${t.getMonth()+1}月${t.getDate()}日`}function C(){return r.isRecognizing?`<div class="status-box loading">${I(r.progressText||`正在识别，请稍候...`)}</div>`:r.extractedResult?r.finalResult?`
    <div class="result-grid">
      ${w(`productionDate`)}
      ${w(`shelfLife`)}
      <div><span>到期日期</span><strong>${S(r.finalResult.expiryDate??r.finalResult.currentDate)}</strong></div>
      <div><span>当前日期</span><strong>${S(r.finalResult.currentDate)}</strong></div>
      <div><span>是否过期</span><strong class="${r.finalResult.isExpired?`expired`:`fresh`}">${E(r.finalResult.isExpired)}</strong></div>
    </div>
    ${r.adjustError?`<div class="status-box warning">调整失败：${I(r.adjustError)}</div>`:``}
    ${T(r.finalResult.recognizedText)}
  `:`
      <div class="status-box warning">错误：${I(r.extractedResult.reason??`无法提取信息。`)}</div>
      ${T(r.extractedResult.recognizedText)}
    `:`<div class="empty-box">拍摄完成后，点击“开始识别”提取生产日期和保质期。</div>`}function w(e){let t=e===`productionDate`,n=t?r.editingProductionDate:r.editingShelfLife,i=t?`productionDateInput`:`shelfLifeInput`,a=t?`editProductionDateButton`:`editShelfLifeButton`,o=t?`saveProductionDateButton`:`saveShelfLifeButton`,s=t?`cancelProductionDateButton`:`cancelShelfLifeButton`,c=t?`生产日期`:`保质期`,l=t?`例如 2026-05-09`:`例如 30天 / 6个月 / 1年`,u=t?r.editableProductionDate:r.editableShelfLife,d=t?h(u)??``:``,f=t?u?S(u):`未识别到`:u||`未识别到`;return n?`
    <div class="adjustable-card editing">
      <span>${c}</span>
      <input
        id="${i}"
        type="${t?`date`:`text`}"
        value="${I(t?d:u)}"
        placeholder="${l}"
        ${t?`max="${x()}"`:``}
      />
      ${t?`<small class="input-hint">点日期框后，直接用系统的年月日选择器调整。</small>`:``}
      <div class="inline-actions">
        <button id="${o}" class="field-btn primary-inline-btn">保存</button>
        <button id="${s}" class="field-btn">取消</button>
      </div>
    </div>
  `:`
      <div class="adjustable-card">
        <span>${c}</span>
        <strong>${I(f)}</strong>
        <button id="${a}" class="field-btn">调整</button>
      </div>
    `}function T(e){return e.trim()?`
    <details class="details-box">
      <summary>查看识别到的原始文字</summary>
      <pre>${I(e)}</pre>
    </details>
  `:``}function E(e){return e===!0?`已过期`:e===!1?`未过期`:`暂时无法判断`}function D(e){if(!r.extractedResult)return;let t=u(r.editableProductionDate,r.editableShelfLife,r.extractedResult.recognizedText,r.extractedResult.currentDate);if(t.isExpired===null){r.adjustError=t.reason,i();return}r.finalResult=t,r.adjustError=null,e===`productionDate`?r.editingProductionDate=!1:r.editingShelfLife=!1,i()}function O(e){r.finalResult&&(e===`productionDate`?(r.editableProductionDate=r.finalResult.productionDate??``,r.editingProductionDate=!1):(r.editableShelfLife=r.finalResult.shelfLifeText??``,r.editingShelfLife=!1),r.adjustError=null,i())}function k(){return r.isInstalled||r.installGuideDismissed?``:r.deferredInstallPrompt?`
      <section class="install-guide">
        <div>
          <p class="install-guide-title">建议安装到桌面</p>
          <p class="install-guide-text">安装后会像 App 一样全屏打开，下次在手机桌面点一下就能进入。</p>
        </div>
        <div class="install-guide-actions">
          <button id="installAppButton" class="primary-btn">立即安装</button>
          <button id="dismissInstallGuideButton" class="ghost-btn">稍后再说</button>
        </div>
      </section>
    `:N()?`
      <section class="install-guide">
        <div>
          <p class="install-guide-title">可添加到手机桌面</p>
          <p class="install-guide-text">iPhone 请先点浏览器底部“分享”，再选择“添加到主屏幕”，以后就能像打开 App 一样进入。</p>
        </div>
        <div class="install-guide-actions">
          <button id="dismissInstallGuideButton" class="ghost-btn">我知道了</button>
        </div>
      </section>
    `:``}function A(){window.addEventListener(`beforeinstallprompt`,t=>{t.preventDefault(),r.deferredInstallPrompt=t,r.installGuideDismissed=!1,localStorage.removeItem(e),i()}),window.addEventListener(`appinstalled`,()=>{r.isInstalled=!0,r.deferredInstallPrompt=null,i()})}async function j(){if(!r.deferredInstallPrompt)return;let t=r.deferredInstallPrompt;await t.prompt();let n=await t.userChoice;r.deferredInstallPrompt=null,n.outcome!==`accepted`&&(r.installGuideDismissed=!0,localStorage.setItem(e,`1`)),i()}function M(){r.installGuideDismissed=!0,localStorage.setItem(e,`1`),i()}function N(){return P()&&!r.isInstalled}function P(){return/iphone|ipad|ipod/i.test(window.navigator.userAgent)}function F(){let e=window.navigator;return window.matchMedia(`(display-mode: standalone)`).matches||e.standalone===!0}function I(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#39;`)}