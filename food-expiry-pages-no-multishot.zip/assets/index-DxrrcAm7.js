(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`food-expiry-install-dismissed`,t=`https://1259665212-djiyi59a60.ap-shanghai.tencentscf.com`,n=1080,r=.62,i=4,a=document.querySelector(`#app`);if(!a)throw Error(`App root not found`);var o={photos:[],isRecognizing:!1,progressText:``,extractedResult:null,finalResult:null,editableProductionDate:``,editableShelfLife:``,editingProductionDate:!1,editingShelfLife:!1,adjustError:null,deferredInstallPrompt:null,isInstalled:J(),installGuideDismissed:localStorage.getItem(e)===`1`};U(),s();function s(){a.innerHTML=`
    <div class="page">
      ${H()}
      <header class="hero-card">
        <p class="eyebrow">可放到手机桌面，像平时点 App 一样打开</p>
        <h1>食品保质期检测</h1>
        <p class="intro">
          把食品包装上能拍到的地方都拍下来。系统会帮你找出生产日期、保质期和到期日期，并告诉你是不是已经过期。
        </p>
        <p class="tips">
          温馨提示：照片上传后，需要等几秒钟系统帮你识别。网络慢时请耐心等待。放到手机桌面后，下次打开会更方便。
        </p>
      </header>

      <section class="card">
        <div class="section-head">
          <h2>拍照检查</h2>
          <span class="pill">已添加 ${o.photos.length} 张</span>
        </div>
        <div class="actions">
          <button id="takePhotoButton" class="primary-btn" ${o.isRecognizing?`disabled`:``}>拍一张</button>
          <button id="pickPhotoButton" class="ghost-btn" ${o.isRecognizing?`disabled`:``}>从相册添加</button>
          <button id="analyzeButton" class="secondary-btn" ${o.photos.length===0||o.isRecognizing?`disabled`:``}>开始检查</button>
          <button id="clearButton" class="ghost-btn" ${o.photos.length===0||o.isRecognizing?`disabled`:``}>清空重拍</button>
        </div>
        <div class="speed-tips">
          <strong>拍照建议：</strong>建议拍 2 到 4 张，重点拍清楚“保质期说明”和“喷码日期”。如果一次拍不清，可以多拍几张再检查。
        </div>
        ${o.photos.length>i?`<div class="status-box warning">现在图片有点多，建议控制在 4 张以内，这样会更快。</div>`:``}
        <input id="takePhotoInput" class="hidden-input" type="file" accept="image/*" capture="environment" />
        <input id="albumInput" class="hidden-input" type="file" accept="image/*" multiple />
        ${o.isRecognizing?`<div class="status-box loading">
                <div>${Y(o.progressText||`正在检查，请稍候...`)}</div>
                <small>一般需要 8 到 15 秒，请不要关闭页面。</small>
              </div>`:``}
        ${o.photos.length===0?`<div class="empty-box">还没有照片，请先拍包装正面、背面、侧面，以及日期附近的位置。</div>`:`<div class="photo-grid">
                ${o.photos.map(e=>`
                      <article class="photo-card">
                        <img src="${e.previewUrl}" alt="${Y(e.label)}" />
                        <div class="photo-meta">
                          <span>${Y(e.label)}</span>
                          <button class="link-btn" data-remove-photo="${e.id}" ${o.isRecognizing?`disabled`:``}>删除</button>
                        </div>
                      </article>
                    `).join(``)}
              </div>`}
      </section>

      <section class="card result-card">
        <div class="section-head">
          <h2>判断结果</h2>
          <span class="pill">当前日期 ${O(D())}</span>
        </div>
        ${F()}
      </section>
    </div>
  `,c()}function c(){let e=document.querySelector(`#takePhotoInput`),t=document.querySelector(`#albumInput`),n=document.querySelector(`#takePhotoButton`),r=document.querySelector(`#pickPhotoButton`),i=document.querySelector(`#analyzeButton`),a=document.querySelector(`#clearButton`),c=document.querySelector(`#productionDateYear`),p=document.querySelector(`#productionDateMonth`),m=document.querySelector(`#productionDateDay`),h=document.querySelector(`#shelfLifeValue`),g=document.querySelector(`#shelfLifeUnit`),_=document.querySelector(`#installAppButton`),v=document.querySelector(`#dismissInstallGuideButton`),y=document.querySelector(`#editProductionDateButton`),b=document.querySelector(`#saveProductionDateButton`),x=document.querySelector(`#cancelProductionDateButton`),S=document.querySelector(`#editShelfLifeButton`),C=document.querySelector(`#saveShelfLifeButton`),w=document.querySelector(`#cancelShelfLifeButton`);n?.addEventListener(`click`,()=>e?.click()),r?.addEventListener(`click`,()=>t?.click()),e?.addEventListener(`change`,t=>{l(Array.from(t.target.files??[])),e&&(e.value=``)}),t?.addEventListener(`change`,e=>{l(Array.from(e.target.files??[])),t&&(t.value=``)}),i?.addEventListener(`click`,()=>{f()}),a?.addEventListener(`click`,()=>d());let T=e=>{if(!c||!p||!m)return;let t=Number(c.value),n=Number(p.value),r=A(t,n),i=Math.min(Number(m.value),r);o.editableProductionDate=`${t}-${String(n).padStart(2,`0`)}-${String(i).padStart(2,`0`)}`,e&&s()};c?.addEventListener(`change`,()=>T(!0)),p?.addEventListener(`change`,()=>T(!0)),m?.addEventListener(`change`,()=>T(!1));let E=e=>{if(!h||!g)return;let t=g.value,n=j(t);o.editableShelfLife=`${Math.min(Number(h.value),n)}${t===`day`?`天`:t===`month`?`个月`:`年`}`,e&&s()};h?.addEventListener(`change`,()=>E(!1)),g?.addEventListener(`change`,()=>E(!0)),document.querySelectorAll(`[data-remove-photo]`).forEach(e=>{e.addEventListener(`click`,()=>{u(e.dataset.removePhoto??``)})}),_?.addEventListener(`click`,()=>{W()}),v?.addEventListener(`click`,()=>{G()}),y?.addEventListener(`click`,()=>{o.adjustError=null,o.editingProductionDate=!0,s()}),b?.addEventListener(`click`,()=>{B(`productionDate`)}),x?.addEventListener(`click`,()=>{V(`productionDate`)}),S?.addEventListener(`click`,()=>{o.adjustError=null,o.editingShelfLife=!0,s()}),C?.addEventListener(`click`,()=>{B(`shelfLife`)}),w?.addEventListener(`click`,()=>{V(`shelfLife`)})}function l(e){if(e.length===0)return;let t=e.map((e,t)=>({id:crypto.randomUUID(),file:e,label:`包装第 ${o.photos.length+t+1} 面`,previewUrl:URL.createObjectURL(e)}));o.photos=[...o.photos,...t],o.extractedResult=null,o.finalResult=null,o.editableProductionDate=``,o.editableShelfLife=``,o.editingProductionDate=!1,o.editingShelfLife=!1,o.adjustError=null,s()}function u(e){let t=o.photos.find(t=>t.id===e);t&&URL.revokeObjectURL(t.previewUrl),o.photos=o.photos.filter(t=>t.id!==e).map((e,t)=>({...e,label:`包装第 ${t+1} 面`})),o.extractedResult=null,o.finalResult=null,o.editableProductionDate=``,o.editableShelfLife=``,o.editingProductionDate=!1,o.editingShelfLife=!1,o.adjustError=null,s()}function d(){o.photos.forEach(e=>URL.revokeObjectURL(e.previewUrl)),o.photos=[],o.extractedResult=null,o.finalResult=null,o.editableProductionDate=``,o.editableShelfLife=``,o.editingProductionDate=!1,o.editingShelfLife=!1,o.adjustError=null,o.progressText=``,s()}async function f(){if(o.photos.length!==0){o.isRecognizing=!0,o.progressText=`正在准备照片...`,o.extractedResult=null,o.finalResult=null,s();try{let e=[];for(let[t,n]of o.photos.entries())o.progressText=`正在处理第 ${t+1} / ${o.photos.length} 张照片...`,s(),e.push(await S(n.file));o.progressText=o.photos.length>i?`照片较多，处理会慢一些，请耐心等待...`:`正在帮你识别，请稍候...`,s();let t=await x(e);o.extractedResult=t,o.finalResult=t.isExpired===null?null:t,o.editableProductionDate=t.productionDate??``,o.editableShelfLife=t.shelfLifeText??``,o.editingProductionDate=!1,o.editingShelfLife=!1,o.adjustError=null}catch(e){let t=e instanceof Error?e.message:`识别时出现异常，请重新尝试。`;o.extractedResult={productionDate:null,shelfLifeText:null,expiryDate:null,currentDate:D(),isExpired:null,reason:`识别失败：${t}`,remainingDays:null,recognizedText:``},o.finalResult=null,o.editableProductionDate=``,o.editableShelfLife=``,o.editingProductionDate=!1,o.editingShelfLife=!1,o.adjustError=null}finally{o.isRecognizing=!1,o.progressText=``,s()}}}function p(e,t,n,r){let i=v(e);if(!i)return{productionDate:null,shelfLifeText:t.trim()||null,expiryDate:null,currentDate:r,isExpired:null,remainingDays:null,reason:`生产日期格式不正确，请输入例如 2026-05-09。`,recognizedText:n};let a=m(t);if(!a)return{productionDate:i,shelfLifeText:t.trim()||null,expiryDate:null,currentDate:r,isExpired:null,remainingDays:null,reason:`保质期格式不正确，请输入例如 30天、6个月、1年。`,recognizedText:n};let o=b(_(y(i),a)),s=k(r,o),c=s<0;return{productionDate:i,shelfLifeText:a.rawText,expiryDate:o,currentDate:r,isExpired:c,remainingDays:s,reason:null,recognizedText:n}}function m(e){let t=e.replace(/\s+/g,``).trim(),n=t.match(/^(\d{1,3})(个?月|天|日|年)$/);return n?g(n[1],n[2]):h(t)}function h(e){for(let t of e.matchAll(/(保质期|保存期|质保期|保期|保藏期|贮藏期|賞味期限|最佳食用期|建议尽快饮用)[:：]?[^\d]{0,8}(\d{1,3})\s*(个?月|天|日|年)/gi)){let e=g(t[2],t[3]);if(e)return e}for(let t of e.matchAll(/(\d{1,3})\s*(个?月|天|日|年)/g)){let n=Math.max(0,(t.index??0)-12),r=e.slice(n,n+24);if(/(保质期|保存期|质保期|保期|保藏期|贮藏期|常温保存|阴凉干燥处|开盖后|冷藏)/.test(r))return g(t[1],t[2])}return null}function g(e,t){let n=Number.parseInt(e,10);return Number.isNaN(n)||n<=0?null:t===`天`||t===`日`?{value:n,unit:`day`,rawText:`${n}${t}`}:t===`个月`||t===`月`?{value:n,unit:`month`,rawText:`${n}${t}`}:t===`年`?{value:n,unit:`year`,rawText:`${n}${t}`}:null}function _(e,t){let n=new Date(e.getTime());return t.unit===`day`?n.setDate(n.getDate()+t.value):t.unit===`month`?n.setMonth(n.getMonth()+t.value):n.setFullYear(n.getFullYear()+t.value),n}function v(e){let t=e.trim().replaceAll(`年`,`-`).replaceAll(`月`,`-`).replaceAll(`日`,``).replaceAll(`/`,`-`).replaceAll(`.`,`-`),n=t.match(/^(20\d{2})(\d{2})(\d{2})$/);if(n)return v(`${n[1]}-${n[2]}-${n[3]}`);let r=t.match(/^(20\d{2})-(\d{1,2})-(\d{1,2})$/);if(!r)return null;let i=Number.parseInt(r[1],10),a=Number.parseInt(r[2],10),o=Number.parseInt(r[3],10),s=new Date(i,a-1,o);return s.getFullYear()!==i||s.getMonth()!==a-1||s.getDate()!==o?null:`${i}-${String(a).padStart(2,`0`)}-${String(o).padStart(2,`0`)}`}function y(e){let[t,n,r]=e.split(`-`).map(e=>Number.parseInt(e,10));return new Date(t,n-1,r)}function b(e){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}async function x(e){let n=await fetch(t,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({op:`run`,images:e})}),r=await n.json().catch(()=>null);if(!n.ok)throw Error(r?.reason||`云端接口请求失败（${n.status}）`);if(!r)throw Error(`云端接口没有返回有效数据。`);return{productionDate:r.productionDate??null,shelfLifeText:r.shelfLifeText??null,expiryDate:r.expiryDate??null,currentDate:r.currentDate??D(),isExpired:r.isExpired??null,remainingDays:typeof r.remainingDays==`number`?r.remainingDays:null,reason:r.reason??null,recognizedText:r.recognizedText??``}}async function S(e){let t=await C(e);return{fileName:e.name||`photo-${Date.now()}.jpg`,contentType:`image/jpeg`,dataUrl:t}}async function C(e){let t=await T(e);if(!e.type.startsWith(`image/`))return t;try{let e=await E(t),i=Math.min(1,n/Math.max(e.naturalWidth,e.naturalHeight)),a=Math.max(1,Math.round(e.naturalWidth*i)),o=Math.max(1,Math.round(e.naturalHeight*i)),s=document.createElement(`canvas`);s.width=a,s.height=o;let c=s.getContext(`2d`);return c?(c.drawImage(e,0,0,a,o),await w(s,r)):t}catch{return t}}function w(e,t){return new Promise(n=>{e.toBlob(r=>{if(!r){n(e.toDataURL(`image/jpeg`,t));return}let i=new FileReader;i.onload=()=>{n(typeof i.result==`string`?i.result:e.toDataURL(`image/jpeg`,t))},i.onerror=()=>n(e.toDataURL(`image/jpeg`,t)),i.readAsDataURL(r)},`image/jpeg`,t)})}function T(e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>{if(typeof r.result==`string`){t(r.result);return}n(Error(`读取图片失败，请重试。`))},r.onerror=()=>n(Error(`读取图片失败，请重试。`)),r.readAsDataURL(e)})}function E(e){return new Promise((t,n)=>{let r=new Image;r.onload=()=>t(r),r.onerror=()=>n(Error(`图片解码失败，请重试。`)),r.src=e})}function D(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}function O(e){let t=y(e);return`${t.getFullYear()}年${t.getMonth()+1}月${t.getDate()}日`}function k(e,t){let n=y(e),r=y(t);return Math.floor((r.getTime()-n.getTime())/864e5)}function A(e,t){return new Date(e,t,0).getDate()}function j(e){return e===`day`?365:e===`month`?36:10}function M(e,t,n){return e.map(e=>`<option value="${e}" ${e===t?`selected`:``}>${n(e)}</option>`).join(``)}function N(e){let[t,n,r]=(v(e)??D()).split(`-`),i=Number(t),a=Number(n),o=Number(r),s=new Date().getFullYear(),c=Math.max(2e3,s-20),l=Array.from({length:s-c+1},(e,t)=>s-t),u=Array.from({length:12},(e,t)=>t+1),d=Array.from({length:A(i,a)},(e,t)=>t+1);return`
    <div class="date-picker-group production-date-picker-group">
      <label class="date-picker-field date-picker-field-year" for="productionDateYear">
        <span>年份</span>
        <select id="productionDateYear">
          ${M(l,i,e=>`${e}`)}
        </select>
      </label>
      <label class="date-picker-field" for="productionDateMonth">
        <span>月份</span>
        <select id="productionDateMonth">
          ${M(u,a,e=>`${e}`)}
        </select>
      </label>
      <label class="date-picker-field" for="productionDateDay">
        <span>日期</span>
        <select id="productionDateDay">
          ${M(d,o,e=>`${e}`)}
        </select>
      </label>
    </div>
  `}function P(e){let t=m(e)??{value:12,unit:`month`,rawText:`12个月`};return`
    <div class="date-picker-group shelf-life-picker-group">
      <label class="date-picker-field" for="shelfLifeValue">
        <span>数值</span>
        <select id="shelfLifeValue">
          ${M(Array.from({length:j(t.unit)},(e,t)=>t+1),t.value,e=>`${e}`)}
        </select>
      </label>
      <label class="date-picker-field" for="shelfLifeUnit">
        <span>单位</span>
        <select id="shelfLifeUnit">
          ${[{value:`day`,label:`天`},{value:`month`,label:`月`},{value:`year`,label:`年`}].map(e=>`<option value="${e.value}" ${e.value===t.unit?`selected`:``}>${e.label}</option>`).join(``)}
        </select>
      </label>
    </div>
  `}function F(){return o.isRecognizing?`<div class="status-box loading">${Y(o.progressText||`正在识别，请稍候...`)}</div>`:o.extractedResult?o.finalResult?`
    <div class="result-grid">
      ${I(`productionDate`)}
      ${I(`shelfLife`)}
      <div><span>到期日期</span><strong>${O(o.finalResult.expiryDate??o.finalResult.currentDate)}</strong></div>
      <div><span>还剩天数</span><strong class="${o.finalResult.remainingDays!==null&&o.finalResult.remainingDays<0?`expired`:`fresh`}">${z(o.finalResult.remainingDays)}</strong></div>
      <div><span>当前日期</span><strong>${O(o.finalResult.currentDate)}</strong></div>
      <div><span>是否过期</span><strong class="${o.finalResult.isExpired?`expired`:`fresh`}">${R(o.finalResult.isExpired)}</strong></div>
    </div>
    ${o.adjustError?`<div class="status-box warning">调整失败：${Y(o.adjustError)}</div>`:``}
    ${L(o.finalResult.recognizedText)}
  `:`
      <div class="status-box warning">错误：${Y(o.extractedResult.reason??`无法提取信息。`)}</div>
      ${L(o.extractedResult.recognizedText)}
    `:`<div class="empty-box">拍照完成后，点“开始检查”，系统就会帮你找出生产日期和保质期。</div>`}function I(e){let t=e===`productionDate`,n=t?o.editingProductionDate:o.editingShelfLife,r=t?`editProductionDateButton`:`editShelfLifeButton`,i=t?`saveProductionDateButton`:`saveShelfLifeButton`,a=t?`cancelProductionDateButton`:`cancelShelfLifeButton`,s=t?`生产日期`:`保质期`,c=t?o.editableProductionDate:o.editableShelfLife,l=t?c?O(c):`未识别到`:c||`未识别到`;return n?`
    <div class="adjustable-card editing">
      <span>${s}</span>
      ${t?`${N(c)}<small class="input-hint">请按顺序选择年、月、日。</small>`:`${P(c)}<small class="input-hint">请先选数字，再选单位。</small>`}
      <div class="inline-actions">
        <button id="${i}" class="field-btn primary-inline-btn">保存</button>
        <button id="${a}" class="field-btn">取消</button>
      </div>
    </div>
  `:`
      <div class="adjustable-card">
        <span>${s}</span>
        <strong>${Y(l)}</strong>
        <button id="${r}" class="field-btn">调整</button>
      </div>
    `}function L(e){return e.trim()?`
    <details class="details-box">
      <summary>查看识别到的原始文字</summary>
      <pre>${Y(e)}</pre>
    </details>
  `:``}function R(e){return e===!0?`已过期`:e===!1?`未过期`:`暂时无法判断`}function z(e){return e===null?`暂时无法判断`:e>0?`还剩 ${e} 天`:e===0?`今天到期`:`已超过 ${Math.abs(e)} 天`}function B(e){if(!o.extractedResult)return;let t=p(o.editableProductionDate,o.editableShelfLife,o.extractedResult.recognizedText,o.extractedResult.currentDate);if(t.isExpired===null){o.adjustError=t.reason,s();return}o.finalResult=t,o.adjustError=null,e===`productionDate`?o.editingProductionDate=!1:o.editingShelfLife=!1,s()}function V(e){o.finalResult&&(e===`productionDate`?(o.editableProductionDate=o.finalResult.productionDate??``,o.editingProductionDate=!1):(o.editableShelfLife=o.finalResult.shelfLifeText??``,o.editingShelfLife=!1),o.adjustError=null,s())}function H(){return o.isInstalled||o.installGuideDismissed?``:o.deferredInstallPrompt?`
      <section class="install-guide">
        <div>
          <p class="install-guide-title">建议放到手机桌面</p>
          <p class="install-guide-text">放到桌面后，下次只要点一下图标，就能直接打开，不用再去浏览器里找。</p>
        </div>
        <div class="install-guide-actions">
          <button id="installAppButton" class="primary-btn">放到桌面</button>
          <button id="dismissInstallGuideButton" class="ghost-btn">稍后再说</button>
        </div>
      </section>
    `:K()?`
      <section class="install-guide">
        <div>
          <p class="install-guide-title">可放到手机桌面</p>
          <p class="install-guide-text">iPhone 请先点浏览器下面的“分享”，再点“添加到主屏幕”，以后就能直接从桌面打开。</p>
        </div>
        <div class="install-guide-actions">
          <button id="dismissInstallGuideButton" class="ghost-btn">我知道了</button>
        </div>
      </section>
    `:``}function U(){window.addEventListener(`beforeinstallprompt`,t=>{t.preventDefault(),o.deferredInstallPrompt=t,o.installGuideDismissed=!1,localStorage.removeItem(e),s()}),window.addEventListener(`appinstalled`,()=>{o.isInstalled=!0,o.deferredInstallPrompt=null,s()})}async function W(){if(!o.deferredInstallPrompt)return;let t=o.deferredInstallPrompt;await t.prompt();let n=await t.userChoice;o.deferredInstallPrompt=null,n.outcome!==`accepted`&&(o.installGuideDismissed=!0,localStorage.setItem(e,`1`)),s()}function G(){o.installGuideDismissed=!0,localStorage.setItem(e,`1`),s()}function K(){return q()&&!o.isInstalled}function q(){return/iphone|ipad|ipod/i.test(window.navigator.userAgent)}function J(){let e=window.navigator;return window.matchMedia(`(display-mode: standalone)`).matches||e.standalone===!0}function Y(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#39;`)}